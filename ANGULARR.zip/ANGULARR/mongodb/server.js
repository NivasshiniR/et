const express = require('express');
const mongoose = require('mongoose');
const bodyParser = require('body-parser');
const cors = require('cors');

const app = express();
app.use(cors());  // Enable CORS for all origins
app.use(bodyParser.json());  // Parse JSON bodies

// Connect to MongoDB (adjust the URI if needed)
mongoose.connect('mongodb://127.0.0.1:27017/library', { useNewUrlParser: true, useUnifiedTopology: true });

const bookSchema = new mongoose.Schema({
  title: String,
  author: String,
});

const Book = mongoose.model('Book', bookSchema);

// Add a book
app.post('/books', async (req, res) => {
  const book = new Book(req.body);
  await book.save();
  res.json(book);
});

// Get all books (with optional filtering)
app.get('/books', async (req, res) => {
  const books = await Book.find(req.query);
  res.json(books);
});

// Start server
app.listen(3000, () => console.log('Server running on port 3000'));
const app = angular.module('myApp', []);

app.controller('MainController', ['$scope', 'UserService', function($scope, UserService) {
    $scope.users = [];
    $scope.newUser = {};
    $scope.searchQuery = ''; 
    UserService.getUsers().then(function(response) {
        $scope.users = response.data;
    });
    $scope.addUser = function() 
    {
        UserService.addUser($scope.newUser).then(function(response) {
            $scope.users.push(response.data);
            $scope.newUser = {};
        });
    };
}]);
app.factory('UserService', ['$http', function($http) {
    const userService = {};

    userService.getUsers = function() {
        return $http.get('/api/users');
    };

    userService.addUser = function(user) {
        return $http.post('/api/users', user);
    };

    return userService;
}]);
app.directive('userInfo', function() {
    return {
        restrict: 'E',
        scope: {
            user: '='
        },
        template: '<div>Name: {{ user.name }}, Age: {{ user.age }}, City: {{ user.city }}</div>'
    };
});

// server.js
const express = require('express');
const mongoose = require('mongoose');
const bodyParser = require('body-parser');
const cors = require('cors');

const app = express();
const PORT = process.env.PORT || 3000;
app.use(cors());
app.use(bodyParser.json());
app.use(express.static('public'));
mongoose.connect('mongodb://localhost:27017/angularjsDB', {
    useNewUrlParser: true,
    useUnifiedTopology: true
}).then(() => console.log('MongoDB connected'))
.catch(err => console.log(err));
const userSchema = new mongoose.Schema({
    name: String,
    age: Number,
    city: String
});
const User = mongoose.model('User', userSchema);
app.get('/api/users', async (req, res) => {
    try {
        const users = await User.find({});
        res.json(users);
    } catch (err) {
        res.status(500).send(err);
    }
});
app.post('/api/users', async (req, res) => {
    const newUser = new User(req.body);
    try {
        const user = await newUser.save();
        res.json(user);
    } catch (err) {
        res.status(500).send(err);
    }
});

app.listen(PORT, () => {
    console.log(`Server running on http://localhost:${PORT}`);
});
